<template>
  <div>
    <div id="content_wrap" class="payment">
      <div id="top">
        <div id="nav">
          <!-- <a class="btn_back" href="#"><img src="../../assets/img/btn_back.svg" alt="뒤로가기"></a> -->
          <router-link to="/homeBasic" class="btn_back">
            <img src="../../assets/img/btn_back.svg" alt="뒤로가기">
          </router-link>
          <p class="current">결제등록</p>
          <a class="btn_alarm" href="#"><img src="../../assets/img/btn_alarm.svg" alt="알람"></a>
        </div>
        <div id="top_info">
          <p class="info">결제 정보를 등록하시면 간편하게<br>결제하실 수 있습니다.</p>
        </div>
      </div>
      <article class="scontainer">
        <section class="con1">
          <div class="con_info">
            <p class="sec_txt"><span class="black fontBold">신용/체크 카드 등록 시<br></span>1회 세차권, Gift쿠폰, 멤버쉽<br>결제 가능합니다.</p>
          </div>
          <a class="card" href="#" @click = "card_option"><img src="../../assets/img/content/payment01.png" alt="">{{card_state_notice}}</a>
        </section>
        <!-- <section class="con2">
          <div class="con_info">
            <p class="sec_txt"><span class="black fontBold">모바일 간편결제 등록 시<br></span>1회권 세차권만 결제 가능합니다.</p>
          </div>
          <div class="pay_register">
            <a class="naverpay" href="#"><img src="../../assets/img/content/payment02.png" alt="">네이버페이 등록</a>
            <a class="kakaopay" href="#"><img src="../../assets/img/content/payment03.png" alt="">카카오페이 등록</a>
          </div>
        </section> -->
        <section class="how_use">
          <p class="title">이용방법 안내</p>
          <ul>
            <li>
              <p>결제 정보를 등록해두시면 간편하게 이용하실 수있습니다.</p>
            </li>
            <li>
              <p>신용/체크 카드 등록 시 에는 2회 세차권, Gift쿠폰, 멤버쉽 결제만 가능합니다.</p>
            </li>
          </ul>
        </section>
      </article>

    </div>
    <FooterVue></FooterVue>
  </div>
</template>

<script>
import FooterVue from "../footer/FooterVue.vue";

export default {
  components: {
    FooterVue
  },
  mounted(){
    this.$http.post(this.$server+'/userapp/ChkRegCard', {
      mem_no : sessionStorage.getItem("mem_no"),
    },{headers : {
    auth_key :'c83b4631-ff58-43b9-8646-024b12193202'
    }
    }).then(
    (res) => {  // 
      if (res.data.result_code == "Y"){
        console.log("등록해야함");
        this.card_state = "Y";
        this.card_state_notice = "신용/체크 카드 등록";
      }
      else{
        console.log("변경해야함");
        this.card_state = "N"; 
        this.card_state_notice = "신용/체크 카드 변경";
      }
      
    })
  },
  data(){
    return {
      card_state_notice : "신용/체크 카드 등록",
      card_state : "Y",
    }
  },
  methods : {
    card_option(){
      var data = {
        "mallId": '05562973', //KICC 에서 발급한상점 ID
        "payMethodTypeCode": "81", //빌키발급 : 81
        "currency": "00", //통화코드  00:원화
        "clientTypeCode": "00", //결제창 종류 00: 통합결제창 전용
        // "returnUrl": "http://app.sparkpluswash.com/PaymentCardRegisterOk", //인증응답 URL 
        "returnUrl" : this.$server+"/userapp/CardTask?mem_no="+sessionStorage.getItem("mem_no")+"&code="+this.card_state,
        "deviceTypeCode": "mobile", // 교객결제 단말
        "shopOrderNo": "CARD_REGISTER", // 상점 주문번호
        "amount":0, // 결제요청금액
        "orderInfo": { //주문정보
        "goodsName": "SPARK_PLUS 카드등록" //상품명
        },
        "payMethodInfo":{ //결제수단관리정보
          "billKeyMethodInfo":{ // 빌키발급 옵션
          "certType" : "1" // 빌키발급 인증타입 1 : 카드번호,유횩간,생년월일
          }
        }
      };
      this.$http.post('https://pgapi.easypay.co.kr/api/trades/webpay', data,
      {headers : {"Content-type" : "application/json", "Charset" : "utf-8"}}).then((res) => {
        sessionStorage.setItem("url",res.data.authPageUrl);
        location.href=res.data.authPageUrl;

      })
      .catch((error) => {
        console.log(error);
      })
    },
  }
};
</script>